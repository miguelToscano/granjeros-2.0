/*
 * logica.cpp
 *
 *  Created on: 24/03/2018
 *      Author: Matias Figueroa
 */

#include "logica.h"
#include "pantalla.h"
#include "jugador.h"
#include "validaciones.h"
#include <cstdlib>
#include <iostream>

using namespace std;

void Logica::inicio(){
	Pantalla p;
	p.imprimirBienvenida();
	p.imprimirSeparador();
}

void Logica::asignarJugador(Jugador* jugadorPtr){
	string nombre;
	cin >> nombre;
	jugadorPtr->setearNombre(nombre);
}

/* Funcion recursiva, sale cuando el jugador desee salir
o se le acaben los turnos */
void Logica::secuenciaDeJuego(Jugador* jugadorPtr,
		bool* finalizaJuegoPtr, int* turnoComparativoPtr){
	Pantalla p;

	//Detecta si hay un paso de turno
	if(*turnoComparativoPtr > jugadorPtr->obtenerTurno()){
		inicioDeTurno(jugadorPtr);
		(*turnoComparativoPtr)--;
	}

	//Se imprimen las opciones y se espera la respuesta del jugador
	p.imprimirPantallaTurno(jugadorPtr, finalizaJuegoPtr);
	seleccionAccion(jugadorPtr);

	//Analiza si le quedan turnos por jugar y termina el juego en caso de que no
	if(jugadorPtr->obtenerTurno() == 0){
		cout << jugadorPtr->obtenerTurno();
		*finalizaJuegoPtr = true;
		}

	//Si no esta la orden de finalizar el juego vuelve a la secuencia anterior
	if(!(*finalizaJuegoPtr)){
		Logica::secuenciaDeJuego(jugadorPtr, finalizaJuegoPtr,
				turnoComparativoPtr);
		p.saludoFinal(jugadorPtr);
	}
}


void Logica::seleccionAccion(Jugador* jugadorPtr){
	char seleccion;
	cin >> seleccion;
	seleccionMenu(seleccion, jugadorPtr);
}

void Logica::tirarDados(Jugador* jugadorPtr){
	Pantalla p;
	int dado, resultado;
	srand(time(0));
	dado = (rand() % Jugador::maxDado()) + 1;
	resultado = dado * Jugador::multiplicadorDado();
	cout << p.msjTirarDado()
			<< dado
			<< endl
			<< p.msjGalonesGanados()
			<< resultado
			<< endl;
	jugadorPtr->resultadoDados(&resultado);
}

void Logica::inicioDeTurno(Jugador* jugadorPtr){
	tirarDados(jugadorPtr);
}

void Logica::finDeTurno(Jugador* jugadorPtr){
	jugadorPtr->finTurno();
}



void Logica::seleccionMenu(char accion, Jugador* jugadorPtr){
	Pantalla p;
	int fila = 0;
	int columna = 0;
	char tipoCultivo;
	switch(accion){
		case '1':
			jugadorPtr->solicitarUbicacionParcela(&fila, &columna);
			if(Validaciones::tieneAgua(jugadorPtr)){
				if(Validaciones::parcelaValida(&fila, &columna)){
					jugadorPtr->regar(&fila, &columna);
				}
			}
			break;
		case '2':
			{
				int cantidad, costo;
				tipoCultivo = p.solicitarTipoCultivo();
				Cultivo cultivo(tipoCultivo);
				cantidad = p.cantidadAComprar();
				costo = (cantidad) * (cultivo.obtenerCosto());
				int tipoFinal = (int)tipoCultivo - 65;
				if(Validaciones::validarCompra(jugadorPtr, costo)){
					cout << costo;
					jugadorPtr->comprar(tipoFinal, cantidad, costo);
				}
			}
			break;
		case '3':
			jugadorPtr->solicitarUbicacionParcela(&fila, &columna);
			if(Validaciones::puedeCosechar(&fila, &columna, jugadorPtr)){
				jugadorPtr->cosechar(&fila, &columna);
			}
			break;
		case '4':
			{
				tipoCultivo = p.solicitarTipoCultivo();
				Cultivo cultivo(tipoCultivo);
				jugadorPtr->solicitarUbicacionParcela(&fila, &columna);
				if(Validaciones::parcelaValida(&fila, &columna)){
					if(Validaciones::sePuedeSembrar(cultivo.obtenerTipo(),
							&fila, &columna, jugadorPtr)){
						jugadorPtr->sembrar(&cultivo, &fila, &columna, jugadorPtr);
					}
				}

			}

			break;
		case '5':
			Logica::finDeTurno(jugadorPtr);
			break;
		case '9':
			p.menuSalir(jugadorPtr);
			jugadorPtr->sacarTurnos();
			break;
		default:
			cout << "Accion invalida";
	}
}


