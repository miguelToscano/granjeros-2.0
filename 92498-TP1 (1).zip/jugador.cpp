/*
 * jugador.cpp
 *
 *  Created on: 24/03/2018
 *      Author: Matias Figueroa
 */

#include <string>
#include "jugador.h"
#include "pantalla.h"
#include "logica.h"
#include "validaciones.h"
#include "parcela.h"

using namespace std;
//Constructor
Jugador::Jugador(string nombreArg){

	setearNombre(nombre);
	setearCredito(CREDITOS_INICIALES);
	turno = TURNOS;
	setearGalonesDeAgua(0);
	setearAguaTurno(0);
	tipoSemilla[A] = 'A';
	tipoSemilla[B] = 'B';
	tipoSemilla[C] = 'C';
	Cultivo cultivo;


	for(int i = 0; i < (MAX_TIPO_DE_SEMILLA - 1); i++){
		setearCantidadSemillas(i,0);
	}

	for(int filas = 0; filas < (MAX_FILAS_TERRENO - 1); filas++){
		for (int columnas = 0; columnas < (MAX_COLUMNAS_TERRENO - 1); columnas++){
			terreno[filas][columnas].cultivoParcela.cambiarCultivo(&cultivo);
			terreno[filas][columnas].parcelaDisponible();
			terreno[filas][columnas].setearRecuperacion(0);
		}
	}

}

Jugador &Jugador::setearNombre(string nombreArg){
	nombre = nombreArg;
	return *this;
}

Jugador &Jugador::setearCredito(int creditoArg){
	credito = creditoArg;
	return *this;
}

Jugador &Jugador::setearCantidadSemillas(int tipoArg, int cantidadArg){
	cantidadSemillas[tipoArg] = cantidadArg;
	return *this;
}

Jugador &Jugador::setearAguaTurno(int aguaTurnoArg){
	aguaTurno = aguaTurnoArg;
	return *this;
}

Jugador &Jugador::setearGalonesDeAgua(int galonesDeAguaArg){
	galonesDeAgua = galonesDeAguaArg;
	return *this;
}

string Jugador::obtenerNombre(){
	return nombre;
}

int Jugador::obtenerCredito(){
	return credito;
}

char Jugador::obtenerTipoSemilla(int tipoArg){
	return tipoSemilla[tipoArg];
}

int Jugador::obtenerCantidadSemillas(int tipoArg){
	return cantidadSemillas[tipoArg];
}

int Jugador::obtenerAguaTurno(){
	return aguaTurno;
}

int Jugador::obtenerGalonesDeAgua(){
	return galonesDeAgua;
}

int Jugador::obtenerTurno(){
	return turno;
}

void Jugador::restarCredito(int creditoArg){
	if(credito >= creditoArg){
		credito -= creditoArg;
	}
}

void Jugador::sumarCredito(int creditoArg){
	credito += creditoArg;
}

void Jugador::restarSemillas(int tipoArg){
	int resto;
	resto = (obtenerCantidadSemillas(tipoArg) - 1);
	setearCantidadSemillas(tipoArg, resto);
}

void Jugador::restarSemillas(int tipoArg, int cantidadSemillasArg){
	int resto;
	resto = obtenerCantidadSemillas(tipoArg) - cantidadSemillasArg;
	setearCantidadSemillas(tipoArg, resto);
}

void Jugador::sumarSemillas(int tipoArg, int cantidadSemillasArg){
	int suma;
	suma = obtenerCantidadSemillas(tipoArg) + cantidadSemillasArg;
	setearCantidadSemillas(tipoArg, suma);
}

void Jugador::sumarSemillas(int tipoArg){
	int suma = 0;
	suma = (obtenerCantidadSemillas(tipoArg) + 1);
	setearCantidadSemillas(tipoArg, suma);
}

void Jugador::descontarUnidadAgua(){
	if(obtenerAguaTurno() > 0){
		aguaTurno--;
	}else{
		if(obtenerGalonesDeAgua() > 0){
			galonesDeAgua--;
		}
	}
}

void Jugador::ahorrarAgua(){
	int sumaGalones;
	sumaGalones = obtenerGalonesDeAgua() + obtenerAguaTurno();
	if(sumaGalones > MAX_GALONES){
		setearGalonesDeAgua(MAX_GALONES);
	}else{
		setearGalonesDeAgua(sumaGalones);
	}
}

void Jugador::restarTurno(){
	turno--;
}

void Jugador::finTurno(){
	restarTurno();
	ahorrarAgua();
	for(int filas = 0; filas < (MAX_FILAS_TERRENO); filas++){
		for(int columnas = 0; columnas < (MAX_COLUMNAS_TERRENO); columnas++){
			terreno[filas][columnas].pasoDeTurno();
		}
	}
}

void Jugador::sacarTurnos(){
	turno = 0;
}

void Jugador::resultadoDados(int* dadosArg){
	aguaTurno = *dadosArg;
}

void Jugador::sembrar(Cultivo* cultivo, int* fila, int* columna, Jugador* jugadorPtr){
	int tipo = 0;
	Parcela* parcelaPtr = &jugadorPtr->terreno[*fila][*columna];
	tipo = (int)cultivo->obtenerTipo() - 65;
	parcelaPtr->cultivoParcela.cambiarCultivo(cultivo);
	parcelaPtr->ocuparParcela();
	parcelaPtr->bloquearParcela();
	jugadorPtr->restarSemillas(tipo);
}

void Jugador::cosechar(int* filaArg, int* columnaArg){
	Parcela* parcelaPtr = &terreno[*filaArg][*columnaArg];
	int ganancias = 0;
	ganancias =
			parcelaPtr->cultivoParcela.obtenerRentabilidad();
	sumarCredito(ganancias);
	parcelaPtr->liberarParcela();

}

void Jugador::comprar(int tipoArg, int cantidadArg, int costoArg){
	sumarSemillas(tipoArg, cantidadArg);
	restarCredito(costoArg);
}



void Jugador::regar(int *fila, int *columna){
	terreno[*fila][*columna].regarParcela();
	descontarUnidadAgua();
}

//Valida la ubicacion elegida y asigna los valores
void Jugador::solicitarUbicacionParcela(int* filaArg, int* columnaArg){
	Pantalla p;
	*filaArg = p.solicitarFilaParcela();
	*columnaArg = p.solicitarColumnaParcela();
}

int Jugador::maxDado(){
	return MAX_DADO;
}

int Jugador::multiplicadorDado(){
	return MULTIPLICADOR_DADO;
}

int Jugador::maxFilas(){
	return MAX_FILAS_TERRENO;
}

int Jugador::maxColumnas(){
	return MAX_COLUMNAS_TERRENO;
}

int Jugador::maxSemillas(){
	return MAX_TIPO_DE_SEMILLA;
}








