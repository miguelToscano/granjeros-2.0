/*
 * cultivo.h
 *
 *  Created on: 24/03/2018
 *      Author: Matias Figueroa
 */

#ifndef CULTIVO_H_
#define CULTIVO_H_


class Cultivo{
	private:

		char tipo;
		int costoSemilla;
		int tiempoCosecha;
		int rentabilidad;
		int tiempoDeRecuperacion;

	public:

		Cultivo();
		Cultivo(char tipoParametro);

		Cultivo &setearTipo(char tipoArg);
		Cultivo &setearCosto(int costoArg);
		Cultivo &setearTiempoCosecha(int tiempoCosechaArg);
		Cultivo &setearRentabilidad(int rentabilidadArg);
		Cultivo &setearTiempoDeRecuperacion(int tiempoDeRecuperacionArg);

		char obtenerTipo();
		int obtenerCosto();
		int obtenerTiempoCosecha();
		int obtenerRentabilidad();
		int obtenerTIempoDeRecuperacion();

		//Reemplaza el cultivo por el que se le pasa por argumento
		void cambiarCultivo(Cultivo* cultivoArg);
		void pasarTurno();
		void reducirTiempoCosecha();
		void reducirTIempoDeRecuperacion();

};


#endif /* CULTIVO_H_ */
