/*
 * parcela.h
 *
 *  Created on: 24/03/2018
 *      Author: Matias Figueroa
 */

#ifndef PARCELA_H_
#define PARCELA_H_

#include "cultivo.h"

class Parcela{
	private:
		bool disponible;
		bool ocupada;
		bool regada;
		bool podrida;
		bool seca;
		int recuperacion;

		static const char VACIA = 'V';
		static const char PODRIDA = '#';
		static const char SECA = 'S';
		static const char DISPONIBLE = 'D';
		static const char ERROR_CHAR = 'E';
		static const char REGADA = '*';
		static const char SIN_REGAR = ' ';
		static const char COSECHAR = 'Y';

	public:
		Cultivo cultivoParcela;

		Parcela();

		Parcela &setearRecuperacion(int recuperacionArg);

		void liberarParcela();
		bool estaDisponible();
		bool estaSeca();
		bool estaRegada();
		bool estaPodrida();
		bool estaOcupada();

		int obtenerRecuperacion();
		void reducirRecuperacion(); //Resta un tiempo de recuperacion
		void desocuparParcela();
		void desSecarParcela();
		void ocuparParcela();
		void noRegarParcela();
		void pudrirParcela();
		void despudrirParcela();
		void regarParcela();
		void secarParcela();
		void parcelaDisponible();
		void bloquearParcela();
		char imagenRepresentativa();
		char infoParcela();

		void pasoDeTurno();

		void copiarParcela(Parcela* parcelaArg);
};



#endif /* PARCELA_H_ */
