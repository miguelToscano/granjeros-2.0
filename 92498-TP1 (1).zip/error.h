/*
 * errores.h
 *
 *  Created on: 04/04/2018
 *      Author: algo2
 */

#ifndef ERROR_H_
#define ERROR_H_

#include <string>

class Error{
	private:
		//Mensajes de error.
		std::string ER_ACCION_INVALIDA =
			"Ha seleccionado un valor invalido vuelva a intentarlo";
		std::string ER_FONDOS_INSUFICIENTES =
			"No posee el dinero suficiente para comprar dichas semillas.";
		std::string PARCELA_OCUPADA = "Esta parcela esta ocupada";
		std::string SIN_SEMILLAS = "No posee semillas de ese cultivo";
		std::string SIN_AGUA = "No posee agua disponible";
		std::string PARCELA_INVALIDA = "Parcela invalida.";
		std::string ER_CULTIVOS = "Cultivo invalido!!!!  (Respete mayusculas)";
		std::string ER_PARCELA_VACIA = "Esa parcela esta vacia!!";
		std::string ER_PARCELA_PODRIDA = "Esa parcela esta podrida!!";
		std::string ER_PARCELA_SECA = "Esa parcela se te seco, ten cuidado!!";
		std::string ER_FALTA_TIEMPO = "Todavia no puedes cosechar esto";

	public:
		std::string accionInvalida();
		std::string fondosInsuficientes();
		std::string parcelaOcupada();
		std::string sinSemillas();
		std::string sinAgua();
		std::string parcelaInvalida();
		std::string cultivoInvalido();
		std::string	parcelaPodrida();
		std::string parcelaSeca();
		std::string	parcelaVacia();
		std::string faltaTiempo();

};


#endif /* ERROR_H_ */
