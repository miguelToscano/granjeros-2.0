/*
 * logica.h
 *
 *  Created on: 24/03/2018
 *      Author: Matias Figueroa
 */

#ifndef LOGICA_H_
#define LOGICA_H_

class Jugador;

class Logica{
	public:
		static void inicio();
		static void asignarJugador(Jugador* jugadorPtr);
		static void secuenciaDeJuego(Jugador* jugadorPtr,
				bool* finalizaJuegoPtr, int* turnoComparativoPtr);
		static void seleccionAccion(Jugador* jugadorPtr);
		static void seleccionMenu(char accion, Jugador* jugadorPtr);
		static void tirarDados(Jugador* jugadorPtr);
		static void inicioDeTurno(Jugador* jugadorPtr);
		static void finDeTurno(Jugador* jugadorPtr);
		static void finDelJuego();
};


#endif /* LOGICA_H_ */
