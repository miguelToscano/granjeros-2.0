/*
 * pantalla.h
 *
 *  Created on: 24/03/2018
 *      Author: Matias Figueroa
 */

#ifndef INTERFACES_PANTALLA_H_
#define INTERFACES_PANTALLA_H_

#include <string>
#include "jugador.h"

class Jugador;
class Parcela;


class Pantalla{
	private:

			//Mensajes varios
		std::string TITULO = "Bienvenido a Granjeros V 1.0";
		std::string SOLICITAR_NOMBRE = "Ingrese su nombre para empezar";
		std::string SOLICITAR_COLUMNA = "Ingese numero de columna";
		std::string SOLICITAR_FILA = "Ingese numero de fila";
		std::string SOLICITAR_ACCION = "Seleccione una accion:";
		std::string OP1 = "1.Regar //";
		std::string OP2 = "2.Comprar //";
		std::string OP3 = "3.Cosechar //";
		std::string OP4 = "4.Sembrar //";
		std::string OP5 = "5.Pasar turno //";
		std::string OP9 = "9.Salir //";
		std::string SEPARADOR = "------------------------";
		std::string CONFIRME_SALIDA = "Esta seguro que quiere salir? (s/n)";
		std::string SOLICITAR_TIPO_CULTIVO = "Ingrese un tipo de cultivo:: A B o C.";
		std::string SOLICITAR_CANTIDAD = "Cuantas unidades quiere comprar?";
		std::string MENSAJE_TIRAR_DADO = "Se tiro el dado----> Su numero es: ";
		std::string MENSAJE_GALONES_GANADOS =
				"Por ello ha recibido los siguientes galones de agua:";
		std::string DESPEDIDA = "El juego a finalizado, su credito final es: ";



	public:
		void imprimirBienvenida();
		void imprimirPantallaTurno(Jugador* jugadorPtr, bool* estadoJuegoPtr);
		void imprimirMenu();
		void imprimirEstadoDelJugador(Jugador* jugadorPtr);
		void imprimirSeparador();
		void imprimirTerreno(Jugador* jugadorPtr);
		void separadorTerreno();
		int solicitarColumnaParcela();
		int solicitarFilaParcela();
		char menuComprar();
		void menuCosechar();
		void menuRegar();
		void menuSalir(Jugador* jugadorPtr);
		int cantidadAComprar();
		void saludoFinal(Jugador* jugadorPtr);
		char solicitarTipoCultivo();
		std::string msjTirarDado();
		std::string msjGalonesGanados();

};

#endif /* INTERFACES_PANTALLA_H_ */
