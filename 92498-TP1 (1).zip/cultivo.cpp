/*
 * cultivo.cpp
 *
 *  Created on: 25/03/2018
 *      Author: Matias Figueroa
 */

#include "cultivo.h"

Cultivo::Cultivo(){
	setearTipo('V');
	setearCosto(0);
	setearTiempoCosecha(0);
	setearRentabilidad(0);
	setearTiempoDeRecuperacion(0);
}

Cultivo::Cultivo(char tipoParametro){
	setearTipo(tipoParametro);

	if(obtenerTipo() == 'A'){
		setearCosto(1);
		setearTiempoCosecha(2);
		setearRentabilidad(10);
		setearTiempoDeRecuperacion(1);
	}

	if(obtenerTipo() == 'B'){
		setearCosto(3);
		setearTiempoCosecha(4);
		setearRentabilidad(30);
		setearTiempoDeRecuperacion(2);
	}

	if(obtenerTipo() == 'C'){
		setearCosto(2);
		setearTiempoCosecha(1);
		setearRentabilidad(5);
		setearTiempoDeRecuperacion(0);
		}
	}

	Cultivo &Cultivo::setearTipo(char tipoArg){
		tipo = tipoArg;
		return *this;
	}

	Cultivo &Cultivo::setearCosto(int costoArg){
		costoSemilla = costoArg;
		return *this;
	}

	Cultivo &Cultivo::setearTiempoCosecha(int tiempoCosechaArg){
		tiempoCosecha = tiempoCosechaArg;
		return *this;
	}

	Cultivo &Cultivo::setearRentabilidad(int rentabilidadArg){
		rentabilidad = rentabilidadArg;
		return *this;
	}

	Cultivo &Cultivo::setearTiempoDeRecuperacion(int tiempoDeRecuperacionArg){
		tiempoDeRecuperacion = tiempoDeRecuperacionArg;
		return *this;
	}

	char Cultivo::obtenerTipo(){
		return tipo;
	}

	int Cultivo::obtenerCosto(){
		return costoSemilla;
	}

	int Cultivo::obtenerTiempoCosecha(){
		return tiempoCosecha;
	}

	int Cultivo::obtenerRentabilidad(){
		return rentabilidad;
	}

	int Cultivo::obtenerTIempoDeRecuperacion(){
		return tiempoDeRecuperacion;
	}

	void Cultivo::cambiarCultivo(Cultivo* cultivoArg){
		setearTipo(cultivoArg->obtenerTipo());
		setearCosto(cultivoArg->obtenerCosto());
		setearRentabilidad(cultivoArg->obtenerRentabilidad());
		setearTiempoDeRecuperacion(cultivoArg->obtenerTIempoDeRecuperacion());
		setearTiempoCosecha(cultivoArg->obtenerTiempoCosecha());
	}

	void pasarTurno(){

	}

	void Cultivo::reducirTiempoCosecha(){
		tiempoCosecha--;
	}

	void Cultivo::reducirTIempoDeRecuperacion(){
		tiempoDeRecuperacion--;
	}




