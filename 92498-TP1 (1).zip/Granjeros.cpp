//============================================================================
// Name        : Granjeros.cpp
// Author      : Matias Ariel Figueroa
// Version     : 1.0
// Copyright   :
// Description : Trabajo Practino nº1
//============================================================================


#include "pantalla.h"
#include "logica.h"
#include "jugador.h"

int main() {

	//Puntero que va a ser utilizado en todo el programa
	Jugador* jugadorPtr = new Jugador("Nombre");
	//Puntero para terminar el programa
	bool* finalizaJuegoPtr = new bool;
	*finalizaJuegoPtr = false;
	//Puntero para arrancar secuencia de inicio de turno
	int* turnoComparativoPtr = new int();

	Logica::inicio();
	Logica::asignarJugador(jugadorPtr);

	*turnoComparativoPtr = (jugadorPtr->obtenerTurno() + 1);

	Logica::secuenciaDeJuego(jugadorPtr, finalizaJuegoPtr,
			turnoComparativoPtr);

	//Libero memoria
	delete jugadorPtr;
	delete finalizaJuegoPtr;
	delete turnoComparativoPtr;

	return 0;
}
